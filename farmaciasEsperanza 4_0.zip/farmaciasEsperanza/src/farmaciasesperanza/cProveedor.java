package farmaciasesperanza;
import java.sql.ResultSet;

import modelo.proveedor;
import java.util.ArrayList;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class cProveedor {
    ConexionBD cone= new ConexionBD();
    public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <proveedor> lprov = new ArrayList();
        try {
            
           while(rs.next()){
                proveedor prov =new proveedor();
               prov.setCodProv(rs.getString("codigo_prov"));
                prov.setNomProv(rs.getString("nombre_prov"));
                 prov.setDirProv(rs.getString("direccion_prov"));
                  prov.setTelProv(rs.getInt("telefono"));
                  lprov.add(prov);  
            } 
        } catch (SQLException e) {
        }
        return lprov;
         
    }
    public ArrayList listaProv(){
        ArrayList <proveedor> lprov = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_provedor";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lprov=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lprov;
    }
     public ArrayList listaProvNombre(String nom){
        ArrayList <proveedor> lprov = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_provedor where nombre_prov like '"+nom+"%'";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lprov=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lprov;
    }
      public void adiciona(proveedor pro){
        try {
            Connection con;
            con=cone.conecta();

            String sql="INSERT INTO t_provedor(codigo_prov,nombre_prov,direccion_prov,telefono) VALUES ('"+pro.getCodProv()+"','"+pro.getNomProv()+"','"+pro.getDirProv()+"',"+pro.getTelProv()+")";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
       public void modifica(proveedor pro){
        try {
            Connection con;
            con=cone.conecta();
            String sql="UPDATE t_provedor SET nombre_prov='"+pro.getNomProv()+"',direccion_prov='"+pro.getDirProv()+"',telefono="+pro.getTelProv()+" WHERE codigo_prov='"+pro.getCodProv()+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
           public void elimina(String ci){
        try {
            Connection con;
            con=cone.conecta();
            String sql="DELETE FROM t_provedor WHERE codigo_prov ='"+ci+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
