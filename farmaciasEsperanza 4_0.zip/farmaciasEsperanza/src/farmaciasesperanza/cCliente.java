package farmaciasesperanza;
import modelo.cliente;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
public class cCliente {
    ConexionBD cone = new ConexionBD();
    public ArrayList recuperaDatos(ResultSet rs) {
        ArrayList<cliente> lcli = new ArrayList();
        try {
            while (rs.next()) {
                cliente cli = new cliente();
                cli.setCi(rs.getString("ci"));
                cli.setNomCli(rs.getString("nombre_cli"));
                cli.setApeCli(rs.getString("apellido_cli"));
                cli.setTelCli(rs.getInt("telefono_cli"));
                lcli.add(cli);
            }
        } catch (SQLException e) {
        }
        return lcli;
    }
    public ArrayList listaCli() {
        ArrayList<cliente> lcli = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from t_cliente";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lcli = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lcli;
    }
    public ArrayList listaCliNombre(String nom) {
        ArrayList<cliente> lcli = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from t_cliente where nombre_cli like '" + nom + "%'";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lcli = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lcli;
    }
    public void adiciona(cliente cli){
        try {
            Connection con;
            con=cone.conecta();
            String sql="INSERT INTO t_cliente(ci,nombre_cli,apellido_cli,telefono_cli) VALUES ('"+cli.getCi()+"','"+cli.getNomCli()+"','"+cli.getApeCli()+"',"+cli.getTelCli()+")";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
      public void modifica(cliente cli){
        try {
            Connection con;
            con=cone.conecta();
            String sql="UPDATE t_cliente SET nombre_cli='"+cli.getNomCli()+"',apellido_cli='"+cli.getApeCli()+"',telefono_cli="+cli.getTelCli()+" WHERE ci='"+cli.getCi()+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
           public void elimina(String ci){
        try {
            Connection con;
            con=cone.conecta();
            String sql="DELETE FROM t_cliente WHERE ci='"+ci+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
