package farmaciasesperanza;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class cUsuarios {

    ConexionBD cone = new ConexionBD();
    int id;
    String user, clave, nom, nivel;

    public boolean verifica(String user1, String clave1) {
        boolean sw = false;
        Connection con = null;
        try {
            con = cone.conecta();
            String sql = " SELECT * from usuarios where usuario='" + user1 + "' AND clave='" + clave1 + "'";
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            if (rs.next()) {
                user = rs.getString("usuario");
                clave = rs.getString("clave");
                if (user.equals(user1) && clave.equals(clave1)) {
                    sw = true;
                }
                rs.close();
                smt.close();
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(cUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sw;

    }

}
