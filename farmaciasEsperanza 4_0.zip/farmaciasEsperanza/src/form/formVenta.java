package form;

import farmaciasesperanza.ConexionBD;
import farmaciasesperanza.cProducto;
import farmaciasesperanza.cVenta;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import modelo.registroVenta;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class formVenta extends javax.swing.JFrame {

    public String desc = "";
    public String codVen, codProd, nomProd, ciEmp, ciCli;
    public int cant;
    public double pre, precio;
    public String fecha, fechai, fechaf;
    public int op = 0;
    cVenta cven = new cVenta();

    boolean validaDatos() {
        boolean sw = true;
        if (txtCVe.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(null, "Debe ingresar el Codigo de venta");
            txtCVe.requestFocus();
        } else {
            if (txtCop.getText().trim().length() == 0) {
                sw = false;
                JOptionPane.showMessageDialog(null, "Debe ingresar el codigo de un producto");
                txtCop.requestFocus();
            } else {
                if (txtCie.getText().trim().length() == 0) {
                    sw = false;
                    JOptionPane.showMessageDialog(null, "Debe ingresar el ci del empleado");
                    txtCie.requestFocus();
                } else {
                    if (txtCi.getText().trim().length() == 0) {
                        sw = false;
                        JOptionPane.showMessageDialog(null, "Debe ingresar el ci del cliente ");
                        txtCi.requestFocus();
                    } else {
                        if (txtCan.getText().trim().length() == 0) {
                            sw = false;
                            JOptionPane.showMessageDialog(null, "Debe ingresar la cantidad ");
                            txtCan.requestFocus();
                        } else {
                            if (txtPre.getText().trim().length() == 0) {
                                sw = false;
                                JOptionPane.showMessageDialog(null, "Debe ingresar el precio de venta ");
                                txtPre.requestFocus();
                            }

                        }
                    }
                }
            }
        }
        return sw;
    }

    void mostrar(ArrayList<registroVenta> lven) {
        String mat[][] = new String[lven.size()][8];
        int i;
        for (i = 0; i < lven.size(); i++) {
            mat[i][0] = lven.get(i).getCodVen() + "";
            mat[i][1] = lven.get(i).getCodProd() + "";
            mat[i][2] = lven.get(i).getNomProd();
            mat[i][3] = lven.get(i).getCiEmp() + "";
            mat[i][4] = lven.get(i).getCiCli() + "";
            mat[i][5] = lven.get(i).getCant() + "";
            mat[i][6] = lven.get(i).getPre() + "";
            mat[i][7] = lven.get(i).getFecha();

        }
        muestra.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Codigo Venta", "Codigo Producto", "Nombre Producto", "Ci Empleado", "Ci", "Cantidad", "Precio Venta", "Fecha"
                }
        ));
    }

    void recuperaDatos() {
        Date date = txtFec.getDate();
        long d = date.getTime();
        java.sql.Date fecha1 = new java.sql.Date(d);
        codVen = txtCVe.getText();
        codProd = txtCop.getText();
        ciEmp = txtCie.getText();
        ciCli = txtCi.getText();
        cant = Integer.parseInt(txtCan.getText());
        pre = Double.parseDouble(txtPre.getText());
        fecha = "" + fecha1;
      
         
 
    }

    void listado() {

        try {
            ArrayList<registroVenta> lven = new ArrayList();
            desc = JOptionPane.showInputDialog("Codigo Venta", "");
            if (desc.isEmpty()) {

                lven = cven.listaProv();

                mostrar(lven);
            } else {
              int bus = busca.getSelectedIndex();
          
                  lven = cven.listaProvNombre(desc, bus);
              

               
                mostrar(lven);

            }

        } catch (NullPointerException e) {
        }

    }

    void botones(boolean nue, boolean agre, boolean bus, boolean sal) {
        btNue.setEnabled(nue);
        btAgre.setEnabled(agre);
        btBus.setEnabled(bus);
        btSal.setEnabled(sal);
    }

    void habilitaDatos(boolean hab) {

        txtCVe.setEnabled(hab);
        txtCop.setEnabled(hab);
        txtCie.setEnabled(hab);
        txtCi.setEnabled(hab);
        txtCan.setEnabled(hab);
        txtPre.setEnabled(false);

        txtprecio.setEnabled(false);

    }

    void limpiaDatos() {
        txtCVe.setText("");
        txtCop.setText("");
        txtCie.setText("");
        txtCi.setText("");
        txtCan.setText("");
        txtPre.setText("");

        txtprecio.setText("");
    }

    void listadoGeneral() {
        ArrayList<registroVenta> lven = new ArrayList();
        lven = cven.listaProv();
        mostrar(lven);
        if (muestra.getRowCount() > 0) {
            botones(true, false, true, true);
        } else {
            botones(true, false, true, true);
        }
    }

    void elimina() {
        int resp;
        int fila = muestra.getSelectedRow();
        codVen = muestra.getValueAt(fila, 0).toString();
        codProd = muestra.getValueAt(fila, 1).toString();
        String canti = muestra.getValueAt(fila, 5).toString();
        cant = Integer.parseInt(canti);
        fecha = muestra.getValueAt(fila, 7).toString();
        resp = JOptionPane.showConfirmDialog(null, "Desea Eliminar ", "Eliminar", JOptionPane.YES_NO_OPTION);
        if (resp == 0) {
            cven.elimina(codVen, codProd, cant, fecha);
            listadoGeneral();
            JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        }

    }
void recuperaFecha(){
    try {
         Date date = i.getDate();
        long d = date.getTime();
        java.sql.Date fecha1 = new java.sql.Date(d);
             Date date1 = f.getDate();
        long df = date1.getTime();
        java.sql.Date fecha2 = new java.sql.Date(df);
        fechai=""+fecha1;
        fechaf=""+fecha2;
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,"Introduce las fechas");
    }
      
}
    void recuperaDatosTabla() {
        try {
            int fila = muestra.getSelectedRow();
            txtCVe.setText(muestra.getValueAt(fila, 0).toString());
            txtCop.setText(muestra.getValueAt(fila, 1).toString());
            txtCie.setText(muestra.getValueAt(fila, 3).toString());
            txtCi.setText(muestra.getValueAt(fila, 4).toString());
            txtCan.setText(muestra.getValueAt(fila, 5).toString());
            txtPre.setText(muestra.getValueAt(fila, 6).toString());
            String fe = (muestra.getValueAt(fila, 7).toString());
            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
            Date fechatxt;
            fechatxt = formatoFecha.parse(fe);
            txtFec.setDate(fechatxt);
        } catch (ParseException ex) {
            Logger.getLogger(formVenta.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public formVenta() {
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        listadoGeneral();

        habilitaDatos(false);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        muestra = new javax.swing.JTable();
        txtprecio = new javax.swing.JTextField();
        txtCie = new javax.swing.JTextField();
        txtCi = new javax.swing.JTextField();
        txtCan = new javax.swing.JTextField();
        txtPre = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        btMod = new javax.swing.JButton();
        btBus = new javax.swing.JButton();
        btAgre = new javax.swing.JButton();
        btEli = new javax.swing.JButton();
        btNue = new javax.swing.JButton();
        txtCop = new javax.swing.JTextField();
        txtCVe = new javax.swing.JTextField();
        btSal = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        txtFec = new com.toedter.calendar.JDateChooser();
        i = new com.toedter.calendar.JDateChooser();
        f = new com.toedter.calendar.JDateChooser();
        busca = new javax.swing.JComboBox<>();
        jButton7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        muestra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo Venta", "Codigo Producto", "Nombre Producto", "Ci Empleado", "Ci", "Cantidad", "Precio Venta", "Fecha"
            }
        ));
        muestra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                muestraMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(muestra);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 880, 140));

        txtprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprecioActionPerformed(evt);
            }
        });
        getContentPane().add(txtprecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 290, 70, -1));
        getContentPane().add(txtCie, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 210, 280, -1));
        getContentPane().add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, 280, -1));

        txtCan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCanKeyTyped(evt);
            }
        });
        getContentPane().add(txtCan, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 290, 110, -1));
        getContentPane().add(txtPre, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 330, 280, -1));

        jButton4.setText("Imprimir");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 250, 80, -1));

        btMod.setText("Modificar");
        btMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btModActionPerformed(evt);
            }
        });
        getContentPane().add(btMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 210, -1, -1));

        btBus.setText("Buscar");
        btBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBusActionPerformed(evt);
            }
        });
        getContentPane().add(btBus, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 300, 80, -1));

        btAgre.setText("Agregar");
        btAgre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgreActionPerformed(evt);
            }
        });
        getContentPane().add(btAgre, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 170, -1, -1));

        btEli.setText("Eliminar");
        btEli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEliActionPerformed(evt);
            }
        });
        getContentPane().add(btEli, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 210, -1, -1));

        btNue.setText("Nuevo");
        btNue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNueActionPerformed(evt);
            }
        });
        getContentPane().add(btNue, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 170, 80, -1));
        getContentPane().add(txtCop, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, 280, -1));

        txtCVe.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCVeKeyTyped(evt);
            }
        });
        getContentPane().add(txtCVe, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, 280, -1));

        btSal.setText("Salir");
        btSal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalActionPerformed(evt);
            }
        });
        getContentPane().add(btSal, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 250, 80, -1));

        jButton2.setText("jButton2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 210, 30, -1));

        jButton3.setText("jButton3");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 250, 30, -1));

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 170, 30, -1));

        jButton5.setText("Calcular");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 290, -1, -1));

        jButton6.setText("Adicionar Venta");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 132, 130, 30));

        txtFec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtFecMouseClicked(evt);
            }
        });
        getContentPane().add(txtFec, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, 150, -1));
        getContentPane().add(i, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 370, 120, -1));
        getContentPane().add(f, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 370, 120, -1));

        busca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona", "Codigo Venta", "Codigo Producto", "Ci", "Empleado", "Fecha" }));
        getContentPane().add(busca, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 300, -1, -1));

        jButton7.setText("Buscar Fecha");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 370, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/formVenta.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jMenu1.setText("Menu");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBusActionPerformed
        listado();

    }//GEN-LAST:event_btBusActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setVisible(false);
        formMenu a = new formMenu();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu1MouseClicked

    private void txtprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprecioActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            ConexionBD cone = new ConexionBD();
            Connection con = null;
            con = cone.conecta();
            String archivo = "C:/Users/USUARIO/Documents/ProgramacionAvnazada/farmaciasEsperanza/src/reportes/rventa.jasper";
            JasperReport reporte = null;
            reporte = (JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
            Map parametro = new HashMap();
            desc = desc + "%";
            parametro.put("desc", desc);
            jp = JasperFillManager.fillReport(reporte, parametro, con);
            JasperViewer jv = new JasperViewer(jp, false);
            jv.setTitle("REPORTE EMPLEADOS");
            jv.setVisible(true);
        } catch (JRException ex) {

        }

    }//GEN-LAST:event_jButton4ActionPerformed

    private void btAgreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgreActionPerformed

        if (validaDatos() == true) {
            recuperaDatos();
            registroVenta ven = new registroVenta(codVen, codProd, ciEmp, ciCli, cant, pre, fecha);
            cProducto cprod = new cProducto();

            String n = "";
            n = cprod.stock(txtCop.getText());
            int s = Integer.parseInt(n);
            int r = Integer.parseInt(txtCan.getText());
            if (op == 0) {

                if (s >= r) {
                    r = s - r;
                    String nu = String.valueOf(r);
                    cven.adiciona(ven);
                    cprod.modStock(txtCop.getText(), nu);

                    JOptionPane.showMessageDialog(null, "Datos Grabados");

                } else {
                    JOptionPane.showMessageDialog(null, "No hay stock. Stock existente:" + s);
                    txtCan.setEnabled(true);
                    txtCan.requestFocus();
                    habilitaDatos(true);

                }
            } else {
                cven.modifica(ven);
                JOptionPane.showMessageDialog(null, "Datos Modificados");
                habilitaDatos(false);
            }

            listadoGeneral();

            btSal.setText("Salir");
        }
    }//GEN-LAST:event_btAgreActionPerformed

    private void btNueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNueActionPerformed
        limpiaDatos();
        int co = 1;
        try {

            String nc = cven.codigo();
            if (nc.isEmpty()) {

            } else {
                co = Integer.parseInt(nc);
                co = co + 1;

            }
            txtCVe.setText("" + co);
        } catch (NullPointerException e) {
            txtCVe.setText("" + co);
        }

        habilitaDatos(true);
        botones(false, true, false, true);
        btSal.setText("Cancelar");
        txtCVe.requestFocus();
    }//GEN-LAST:event_btNueActionPerformed

    private void btModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btModActionPerformed
        op = 1;
        habilitaDatos(true);
        botones(true, true, true, true);
    }//GEN-LAST:event_btModActionPerformed

    private void muestraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_muestraMouseClicked
        recuperaDatosTabla();
    }//GEN-LAST:event_muestraMouseClicked

    private void btEliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEliActionPerformed
        elimina();
    }//GEN-LAST:event_btEliActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        formProducto a = new formProducto();
        a.setVisible(true);
        formProducto.vp.setText("1");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        formEmpleado a = new formEmpleado();
        a.setVisible(true);
        formEmpleado.ve.setText("1");


    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        formCliente a = new formCliente();
        a.setVisible(true);
        formCliente.vc.setText("1");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        btAgre.setEnabled(true);
        try {
            Double can = Double.parseDouble(txtCan.getText());
            Double ven = Double.parseDouble(txtprecio.getText());
            ven = can * ven;
            txtPre.setText("" + ven);
        } catch (Exception e) {
        }

    }//GEN-LAST:event_jButton5ActionPerformed

    private void btSalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalActionPerformed
        if (btSal.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        } else {
            dispose();
        }
    }//GEN-LAST:event_btSalActionPerformed

    private void txtFecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtFecMouseClicked

    }//GEN-LAST:event_txtFecMouseClicked

    private void txtCanKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCanKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtCanKeyTyped

    private void txtCVeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCVeKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtCVeKeyTyped

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        int co = 0;
        String nc = cven.codigo();
        co = Integer.parseInt(nc);
        txtCVe.setText("" + co);
        habilitaDatos(true);
        botones(false, true, false, true);
        btSal.setText("Cancelar");
        txtCop.requestFocus();
        txtCop.setText("");
        txtCan.setText("");
        txtprecio.setText("");

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
recuperaFecha();
    ArrayList<registroVenta> lven = new ArrayList();
  lven=cven.listaProvFecha(fechai,fechaf);
              mostrar(lven);
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formVenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAgre;
    private javax.swing.JButton btBus;
    private javax.swing.JButton btEli;
    private javax.swing.JButton btMod;
    private javax.swing.JButton btNue;
    private javax.swing.JButton btSal;
    private javax.swing.JComboBox<String> busca;
    private com.toedter.calendar.JDateChooser f;
    private com.toedter.calendar.JDateChooser i;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable muestra;
    private javax.swing.JTextField txtCVe;
    private javax.swing.JTextField txtCan;
    public static javax.swing.JTextField txtCi;
    public static javax.swing.JTextField txtCie;
    public static javax.swing.JTextField txtCop;
    private com.toedter.calendar.JDateChooser txtFec;
    private javax.swing.JTextField txtPre;
    public static javax.swing.JTextField txtprecio;
    // End of variables declaration//GEN-END:variables
}
