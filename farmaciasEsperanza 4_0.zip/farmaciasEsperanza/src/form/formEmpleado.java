package form;

import farmaciasesperanza.ConexionBD;
import farmaciasesperanza.cEmpleado;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

import modelo.empleado;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class formEmpleado extends javax.swing.JFrame {

    public String desc = "";
    cEmpleado cemp = new cEmpleado();
    public String ciEmp, nomEmp, apeEmp, proEmp, dirEmp;
    public int telEmp;
    public int op = 0;

    void habilitaDatos(boolean hab) {
        txtCi.setEnabled(hab);
        txtNom.setEnabled(hab);
        txtApe.setEnabled(hab);
        txtPro.setEnabled(hab);
        txtDir.setEnabled(hab);
        txtTel.setEnabled(hab);

    }

    boolean validaDatos() {
        boolean sw = true;
        if (txtCi.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(null, "Debe ingresar el Ci del Cliente");
            txtCi.requestFocus();
        } else {
            if (txtNom.getText().trim().length() == 0) {
                sw = false;
                JOptionPane.showMessageDialog(null, "Debe ingresar el Nombre del cliente");
                txtNom.requestFocus();
            } else {
                if (txtApe.getText().trim().length() == 0) {
                    sw = false;
                    JOptionPane.showMessageDialog(null, "Debe ingresar el Apellido del cliente");
                    txtApe.requestFocus();
                } else {
                    if (txtPro.getText().trim().length() == 0) {
                        sw = false;
                        JOptionPane.showMessageDialog(null, "Debe ingresar la profesion ");
                        txtTel.requestFocus();
                    } else {
                        if (txtDir.getText().trim().length() == 0) {
                            sw = false;
                            JOptionPane.showMessageDialog(null, "Debe ingresar el Direccion del cliente");
                            txtTel.requestFocus();
                        } else {
                            if (txtTel.getText().trim().length() == 0) {
                                sw = false;
                                JOptionPane.showMessageDialog(null, "Debe ingresar el Telefono del cliente");
                                txtTel.requestFocus();
                            }
                        }
                    }
                }
            }
        }
        return sw;
    }

    void recuperaDatos() {
        ciEmp = txtCi.getText();
        nomEmp = txtNom.getText();
        apeEmp = txtApe.getText();
        proEmp = txtPro.getText();
        dirEmp = txtDir.getText();
        telEmp = Integer.parseInt(txtTel.getText());
    }

    void botones(boolean nue, boolean agre, boolean bus, boolean sal) {
        btNue.setEnabled(nue);
        btAgre.setEnabled(agre);
        btBus.setEnabled(bus);
        btSal.setEnabled(sal);
    }

    void limpiaDatos() {
        txtCi.setText("");
        txtNom.setText("");
        txtApe.setText("");
        txtPro.setText("");
        txtDir.setText("");
        txtTel.setText("");
    }

    void recuperaDatosTabla() {
        int fila = ta.getSelectedRow();
        txtCi.setText(ta.getValueAt(fila, 0).toString());
        txtNom.setText(ta.getValueAt(fila, 1).toString());
        txtApe.setText(ta.getValueAt(fila, 2).toString());
        txtPro.setText(ta.getValueAt(fila, 3).toString());
        txtDir.setText(ta.getValueAt(fila, 4).toString());
        txtTel.setText(ta.getValueAt(fila, 5).toString());
    }

    void mostrar(ArrayList<empleado> lemp) {
        String mat[][] = new String[lemp.size()][6];
        int i;
        for (i = 0; i < lemp.size(); i++) {
            mat[i][0] = lemp.get(i).getCiEmp() + "";
            mat[i][1] = lemp.get(i).getNomEmp();
            mat[i][2] = lemp.get(i).getApeEmp();
            mat[i][3] = lemp.get(i).getProEmp();
            mat[i][4] = lemp.get(i).getDirEmp();
            mat[i][5] = lemp.get(i).getTelEmp() + "";
        }
        ta.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Ci", "Nombre", "Apellido", "Profesion", "Direccion", "Telefono"
                }
        ));
    }

    void listado() {

        try {
            desc = JOptionPane.showInputDialog("Nombre del empleado a buscar", "");
            if (desc.isEmpty()) {
                ArrayList<empleado> lemp = new ArrayList();
                lemp = cemp.listaEmp();
                mostrar(lemp);
            } else {
                ArrayList<empleado> lemp = new ArrayList();
                lemp = cemp.listaEmpNombre(desc);
                mostrar(lemp);
            }
        } catch (NullPointerException e) {
        }

    }

    void elimina() {
        int resp;
        int fila = ta.getSelectedRow();
        ciEmp = ta.getValueAt(fila, 0).toString();
        resp = JOptionPane.showConfirmDialog(null, "Desea Eliminar ", "Eliminar", JOptionPane.YES_NO_OPTION);
        if (resp == 0) {
            cemp.elimina(ciEmp);
            listadoGeneral();
            JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        }

    }

    void listadoGeneral() {
        ArrayList<empleado> lemp = new ArrayList();
        lemp = cemp.listaEmp();
        mostrar(lemp);
        if (pa.getRowCount() > 0) {
            botones(true, false, true, true);
        } else {
            botones(true, false, true, true);
        }
    }

    public formEmpleado() {
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        habilitaDatos(false);
        listadoGeneral();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jTable1 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        pa = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        txtCi = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtApe = new javax.swing.JTextField();
        txtPro = new javax.swing.JTextField();
        btBus = new javax.swing.JButton();
        btAgre = new javax.swing.JButton();
        btNue = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        btSal = new javax.swing.JButton();
        txtDir = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        txtTel = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        ta = new javax.swing.JTable();
        jButton8 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        ve = new javax.swing.JTextField();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();

        jFrame1.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jFrame1.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jFrame1.getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 280, -1));
        jFrame1.getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 280, -1));
        jFrame1.getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 280, -1));
        jFrame1.getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 280, -1));

        jButton5.setText("Buscar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jFrame1.getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 150, 80, -1));

        jButton2.setText("jButton1");
        jFrame1.getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 190, -1, -1));

        jButton4.setText("jButton1");
        jFrame1.getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 230, -1, -1));

        jButton6.setText("jButton1");
        jFrame1.getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 150, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre", "Direccion", "Telefono"
            }
        ));
        jFrame1.getContentPane().add(jTable1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jButton3.setText("jButton1");
        jFrame1.getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, -1, -1));

        jButton1.setText("jButton1");
        jFrame1.getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 230, -1, -1));

        pa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Ci", "Nombre", "Apellido", "Telefono"
            }
        ));
        jScrollPane2.setViewportView(pa);

        jFrame1.getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, 690, 160));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/formcliente.png"))); // NOI18N
        jFrame1.getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        jFrame1.setJMenuBar(jMenuBar1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCiKeyTyped(evt);
            }
        });
        getContentPane().add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 280, -1));

        txtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNomKeyTyped(evt);
            }
        });
        getContentPane().add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 280, -1));

        txtApe.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApeKeyTyped(evt);
            }
        });
        getContentPane().add(txtApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 280, -1));

        txtPro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProKeyTyped(evt);
            }
        });
        getContentPane().add(txtPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 280, -1));

        btBus.setText("Buscar");
        btBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBusActionPerformed(evt);
            }
        });
        getContentPane().add(btBus, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 150, 80, -1));

        btAgre.setText("Agregar");
        btAgre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgreActionPerformed(evt);
            }
        });
        getContentPane().add(btAgre, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 150, 80, -1));

        btNue.setText("Nuevo");
        btNue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNueActionPerformed(evt);
            }
        });
        getContentPane().add(btNue, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 190, 80, -1));

        jButton10.setText("Modificar");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, -1, -1));

        jButton11.setText("Eliminar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 230, 80, -1));

        btSal.setText("Salir");
        btSal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalActionPerformed(evt);
            }
        });
        getContentPane().add(btSal, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 230, 80, -1));
        getContentPane().add(txtDir, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, 280, -1));

        jButton7.setText("Imprimir");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 280, -1, -1));

        txtTel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelKeyTyped(evt);
            }
        });
        getContentPane().add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 340, 280, -1));

        ta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Ci", "Nombre", "Apellido", "Profesion", "Direccion", "Telefono"
            }
        ));
        ta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                taMouseClicked(evt);
            }
        });
        ta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                taKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(ta);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 379, 700, 100));

        jButton8.setText("Venta");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 280, 80, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/formEmpleado.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        ve.setText("0");
        ve.setEnabled(false);
        getContentPane().add(ve, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, -1, -1));

        jMenu3.setText("Menu");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        setJMenuBar(jMenuBar2);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

    }//GEN-LAST:event_jButton5ActionPerformed

    private void btBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBusActionPerformed
        listado();
    }//GEN-LAST:event_btBusActionPerformed

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu3MouseClicked
        this.setVisible(false);
        formMenu a = new formMenu();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu3MouseClicked

    private void btAgreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgreActionPerformed
        if (validaDatos() == true) {
            recuperaDatos();
            empleado emp = new empleado(ciEmp, nomEmp, apeEmp, proEmp, dirEmp, telEmp);
            if (op == 0) {
                cemp.adiciona(emp);
                JOptionPane.showMessageDialog(null, "Datos Grabados");
            } else {
                cemp.modifica(emp);
                JOptionPane.showMessageDialog(null, "Datos Modificados");
            }
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        }
    }//GEN-LAST:event_btAgreActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        op = 1;
        habilitaDatos(true);
        botones(true, true, true, true);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void taMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_taMouseClicked
        recuperaDatosTabla();
    }//GEN-LAST:event_taMouseClicked

    private void taKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_taKeyPressed
        recuperaDatosTabla();
    }//GEN-LAST:event_taKeyPressed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        elimina();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void txtCiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCiKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtCiKeyTyped

    private void txtTelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtTelKeyTyped

    private void txtNomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNomKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtNomKeyTyped

    private void txtApeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApeKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtApeKeyTyped

    private void txtProKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtProKeyTyped

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        try {
            ConexionBD cone = new ConexionBD();
            Connection con = null;
            con = cone.conecta();
            String archivo = "C:/Users/USUARIO/Documents/ProgramacionAvnazada/farmaciasEsperanza/src/reportes/rEmpleado.jasper";
            JasperReport reporte = null;
            reporte = (JasperReport) JRLoader.loadObjectFromFile(archivo);

            JasperPrint jp;
            Map parametro = new HashMap();
            desc = desc + "%";
            parametro.put("desc", desc);
            jp = JasperFillManager.fillReport(reporte, parametro, con);
            JasperViewer jv = new JasperViewer(jp, false);
            jv.setTitle("REPORTE EMPLEADOS");
            jv.setVisible(true);
        } catch (JRException ex) {

        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void btNueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNueActionPerformed
        limpiaDatos();
        habilitaDatos(true);
        botones(false, true, false, true);
        btSal.setText("Cancelar");
        txtCi.requestFocus();
    }//GEN-LAST:event_btNueActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

        if ((ve.getText()).equals("0")) {
            formVenta a = new formVenta();
            a.setVisible(true);

        } else {
        }

        String n = txtCi.getText();
        formVenta.txtCie.setText(n);
        this.setVisible(false);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void btSalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalActionPerformed
        if (btSal.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        } else {
            dispose();
        }
    }//GEN-LAST:event_btSalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formEmpleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formEmpleado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAgre;
    private javax.swing.JButton btBus;
    private javax.swing.JButton btNue;
    private javax.swing.JButton btSal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTable pa;
    private javax.swing.JTable ta;
    private javax.swing.JTextField txtApe;
    private javax.swing.JTextField txtCi;
    private javax.swing.JTextField txtDir;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtPro;
    private javax.swing.JTextField txtTel;
    public static javax.swing.JTextField ve;
    // End of variables declaration//GEN-END:variables

}
