package form;
import farmaciasesperanza.ConexionBD;
import farmaciasesperanza.cProveedor;

import java.sql.Connection;
import modelo.proveedor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
public class formProveedor extends javax.swing.JFrame {
        public String codProv,nomProv,dirProv;
        public String desc="";
    public int telProv;
      public int op = 0;
     
            
cProveedor cprov= new cProveedor();
    public formProveedor() {
          this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        habilitaDatos(false);
       listadoGeneral();
    }
    void mostrar(ArrayList <proveedor> lprov){
          String mat[][]=new String[lprov.size()][4];
          int i;
          for(i=0;i<lprov.size();i++){
              mat [i][0]=lprov.get(i).getCodProv()+"";
              mat [i][1]=lprov.get(i).getNomProv();
              mat [i][2]=lprov.get(i).getDirProv();
              mat [i][3]=lprov.get(i).getTelProv()+"";
          }
          ta1.setModel(new javax.swing.table.DefaultTableModel(
            mat,
            new String [] {
                "Codigo", "Nombre", "Direccion", "Telefono"
            }
        ));
    }
       void listadoGeneral() {
        ArrayList<proveedor> lpro = new ArrayList();
        lpro = cprov.listaProv();
        mostrar(lpro);
        if (ta1.getRowCount() > 0) {
            botones(true, false, true, true);
        } else {
            botones(true, false, true, true);
        }
    }
       void elimina(){
    int resp;
    int  fila=ta1.getSelectedRow();
    codProv=ta1.getValueAt(fila,0).toString();
    resp=JOptionPane.showConfirmDialog(null,"Desea Eliminar ","Eliminar",JOptionPane.YES_NO_OPTION);
    if(resp==0){
         cprov.elimina(codProv);
    listadoGeneral();
    JOptionPane.showMessageDialog(null,"Se elimino correctamente");
    }
    
   
}
    void listado(){
        
      desc ="";
        try {
                 desc= JOptionPane.showInputDialog("Nombre del proveedor a buscar",""); 
                 if(desc.isEmpty()){
          ArrayList<proveedor> lprov=new ArrayList();
          lprov=cprov.listaProv();
          mostrar(lprov);
      }
       else{
           ArrayList<proveedor> lprov=new ArrayList();
          lprov=cprov.listaProvNombre(desc);
          mostrar(lprov);
      }
        } catch (NullPointerException e) { 
        }
      
    }
      void limpiaDatos() {
        txtCod.setText("");
        txtNom.setText("");
        txtDir.setText("");
        txtTel.setText("");
    }
          void recuperaDatosTabla() {
        int fila = ta1.getSelectedRow();
        txtCod.setText(ta1.getValueAt(fila, 0).toString());
        txtNom.setText(ta1.getValueAt(fila, 1).toString());
        txtDir.setText(ta1.getValueAt(fila, 2).toString());
        txtTel.setText(ta1.getValueAt(fila, 3).toString());
    }
     boolean validaDatos() {
        boolean sw = true;
        if (txtCod.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(null, "Debe ingresar el Codigo del Cliente");
            txtCod.requestFocus();
        } else {
            if (txtNom.getText().trim().length() == 0) {
                sw = false;
                JOptionPane.showMessageDialog(null, "Debe ingresar el Nombre del proovedor");
                txtNom.requestFocus();
            } else {
                if (txtDir.getText().trim().length() == 0) {
                    sw = false;
                    JOptionPane.showMessageDialog(null, "Debe ingresar la direccion del proveedor");
                    txtDir.requestFocus();
                } else {
                    if (txtTel.getText().trim().length() == 0) {
                        sw = false;
                        JOptionPane.showMessageDialog(null, "Debe ingresar el Telefono del proveedor");
                        txtTel.requestFocus();
                    }
                }
            }
        }
        return sw;
    }
      void recuperaDatos() {
        codProv = txtCod.getText();
        nomProv = txtNom.getText();
        dirProv = txtDir.getText();
        telProv= Integer.parseInt(txtTel.getText());
    }
       void habilitaDatos(boolean hab) {
        txtCod.setEnabled(hab);
        txtNom.setEnabled(hab);
        txtDir.setEnabled(hab);
        txtTel.setEnabled(hab);

    }
          void botones(boolean nue, boolean agre, boolean bus, boolean sal) {
        btNue.setEnabled(nue);
        btAgre.setEnabled(agre);
        btBus.setEnabled(bus);
        btSal.setEnabled(sal);
    }
       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        ta1 = new javax.swing.JTable();
        txtTel = new javax.swing.JTextField();
        txtCod = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtDir = new javax.swing.JTextField();
        btEli = new javax.swing.JButton();
        btNue = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btSal = new javax.swing.JButton();
        btBus = new javax.swing.JButton();
        btAgre = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        v = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ta1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre", "Direccion", "Telefono"
            }
        ));
        ta1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ta1MouseClicked(evt);
            }
        });
        ta1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ta1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ta1KeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(ta1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 690, 150));

        txtTel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelKeyTyped(evt);
            }
        });
        getContentPane().add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 280, -1));

        txtCod.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodKeyTyped(evt);
            }
        });
        getContentPane().add(txtCod, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 280, -1));

        txtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNomKeyTyped(evt);
            }
        });
        getContentPane().add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 280, -1));
        getContentPane().add(txtDir, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 200, 280, -1));

        btEli.setText("Eliminar");
        btEli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEliActionPerformed(evt);
            }
        });
        getContentPane().add(btEli, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 210, 80, -1));

        btNue.setText("Nuevo");
        btNue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNueActionPerformed(evt);
            }
        });
        getContentPane().add(btNue, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 130, 80, -1));

        jButton3.setText("Modificar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 170, -1, -1));

        btSal.setText("Salir");
        btSal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalActionPerformed(evt);
            }
        });
        getContentPane().add(btSal, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 210, 80, -1));

        btBus.setText("Buscar");
        btBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBusActionPerformed(evt);
            }
        });
        getContentPane().add(btBus, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, 80, -1));

        btAgre.setText("Agregar");
        btAgre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgreActionPerformed(evt);
            }
        });
        getContentPane().add(btAgre, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 130, 80, -1));

        jButton1.setText("Imprimir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 250, -1, -1));

        jButton2.setText("Producto");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 250, -1, -1));

        v.setText("0");
        v.setEnabled(false);
        v.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vActionPerformed(evt);
            }
        });
        getContentPane().add(v, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, 0, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/formProveedor.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 470));

        jMenu1.setText("Menu");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Salir");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBusActionPerformed
        listado();
    }//GEN-LAST:event_btBusActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
          this.setVisible(false);
        formMenu a = new formMenu();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu1MouseClicked

    private void btAgreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgreActionPerformed
        if (validaDatos() == true) {
            recuperaDatos();
            proveedor pro = new proveedor(codProv, nomProv, dirProv, telProv);
            if (op == 0) {
                cprov.adiciona(pro);
                JOptionPane.showMessageDialog(null, "Datos Grabados");
            } else {
                cprov.modifica(pro);
                JOptionPane.showMessageDialog(null, "Datos Modificados");
            }
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        }
    }//GEN-LAST:event_btAgreActionPerformed

    private void btNueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNueActionPerformed
        limpiaDatos();
        habilitaDatos(true);
        botones(false, true, false, true);
        btSal.setText("Cancelar");
        txtCod.requestFocus();
    }//GEN-LAST:event_btNueActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         op = 1;
        habilitaDatos(true);
        botones(true, true, true, true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btEliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEliActionPerformed
       elimina();
    }//GEN-LAST:event_btEliActionPerformed

    private void ta1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ta1MouseClicked
   recuperaDatosTabla();
    }//GEN-LAST:event_ta1MouseClicked

    private void ta1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ta1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_ta1KeyTyped

    private void ta1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ta1KeyPressed
       recuperaDatosTabla();
    }//GEN-LAST:event_ta1KeyPressed

    private void btSalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalActionPerformed
        if (btSal.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        } else {
            dispose();
        }
    }//GEN-LAST:event_btSalActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          try {
            ConexionBD cone=new ConexionBD();
            Connection con =null;
            con=cone.conecta();
            String archivo="C:/Users/USUARIO/Documents/ProgramacionAvnazada/farmaciasEsperanza/src/reportes/rProovedor.jasper";
            JasperReport reporte=null;
            reporte=(JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
            Map parametro =new HashMap();
            desc=desc+"%";
            parametro.put("desc",desc);
            jp=JasperFillManager.fillReport(reporte,parametro,con);
            JasperViewer jv= new JasperViewer(jp,false);
            jv.setTitle("REPORTE PROVEEDORES");
            jv.setVisible(true);
        } catch (JRException ex) {
           
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

 if ((v.getText()).equals("0")){
       formProducto a = new formProducto();
        a.setVisible(true);
        
       
 }else{ 
 }
   String n=txtCod.getText();
   formProducto.txtProv.setText(n);
        this.setVisible(false);
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtCodKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodKeyTyped

    private void txtNomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNomKeyTyped
         char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtNomKeyTyped

    private void txtTelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car)) ) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtTelKeyTyped

    private void vActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_vActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formProveedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAgre;
    private javax.swing.JButton btBus;
    private javax.swing.JButton btEli;
    private javax.swing.JButton btNue;
    private javax.swing.JButton btSal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable ta1;
    public static javax.swing.JTextField txtCod;
    private javax.swing.JTextField txtDir;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtTel;
    public static javax.swing.JTextField v;
    // End of variables declaration//GEN-END:variables
}
