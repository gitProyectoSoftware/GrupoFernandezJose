package form;

import farmaciasesperanza.ConexionBD;
import farmaciasesperanza.cProducto;
import java.sql.Connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import modelo.producto;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class formProducto extends javax.swing.JFrame {
public String desc="";
    public String codProd, codProv, nomProv, nomProd;
    public double preCom, preVen;
    public int stock;
    public int op = 0;
    cProducto cprod = new cProducto();

    boolean validaDatos() {
        boolean sw = true;
        if (txtCod.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(null, "Debe ingresar el Codigo del Producto");
            txtCod.requestFocus();
        } else {
            if (txtProv.getText().trim().length() == 0) {
                sw = false;
                JOptionPane.showMessageDialog(null, "Debe ingresar el codigo de un proveedor");
                txtProv.requestFocus();
            } else {
                if (txtNom.getText().trim().length() == 0) {
                    sw = false;
                    JOptionPane.showMessageDialog(null, "Debe ingresar el nombre del producto");
                    txtNom.requestFocus();
                } else {
                    if (txtCom.getText().trim().length() == 0) {
                        sw = false;
                        JOptionPane.showMessageDialog(null, "Debe ingresar el precio de compra ");
                        txtCom.requestFocus();
                    } else {
                        if (txtVen.getText().trim().length() == 0) {
                            sw = false;
                            JOptionPane.showMessageDialog(null, "Debe ingresar el precio de venta ");
                            txtVen.requestFocus();
                        } else {
                            if (txtSto.getText().trim().length() == 0) {
                                sw = false;
                                JOptionPane.showMessageDialog(null, "Debe ingresar el stock del producto ");
                                txtSto.requestFocus();
                            }
                        }
                    }
                }
            }
        }
        return sw;
    }

    void botones(boolean nue, boolean agre, boolean bus, boolean sal) {
        btNue.setEnabled(nue);
        btAgre.setEnabled(agre);
        btBus.setEnabled(bus);
        btSal.setEnabled(sal);
    }

    void listadoGeneral() {
        ArrayList<producto> lpro = new ArrayList();
        lpro = cprod.listaProv();
        mostrar(lpro);
        if (muestra.getRowCount() > 0) {
            botones(true, false, true, true);
        } else {
            botones(true, false, true, true);
        }
    }

    void mostrar(ArrayList<producto> lprod) {
        String mat[][] = new String[lprod.size()][7];
        int i;
        for (i = 0; i < lprod.size(); i++) {
            mat[i][0] = lprod.get(i).getCodProd() + "";
            mat[i][1] = lprod.get(i).getCodProv() + "";
            mat[i][2] = lprod.get(i).getNomProv();
            mat[i][3] = lprod.get(i).getNomProd();
            mat[i][4] = lprod.get(i).getPreCom() + "";
            mat[i][5] = lprod.get(i).getPreVen() + "";
            mat[i][6] = lprod.get(i).getStock() + "";

        }
        muestra.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Codigo Producto", "Codigo  Proveedor", "Nombre Proveedor", "Nombre Producto", "Precio Compra", "Precio Venta", "Stock"
                }
        ));

    }

    void recuperaDatos() {
        codProd = txtCod.getText();
        codProv = txtProv.getText();
        nomProd = txtNom.getText();
        preCom = Double.parseDouble(txtCom.getText());
        preVen = Double.parseDouble(txtVen.getText());
        stock = Integer.parseInt(txtSto.getText());
    }

    void elimina() {
        int resp;
        int fila = muestra.getSelectedRow();
        codProd = muestra.getValueAt(fila, 0).toString();
        resp = JOptionPane.showConfirmDialog(null, "Desea Eliminar ", "Eliminar", JOptionPane.YES_NO_OPTION);
        if (resp == 0) {
            cprod.elimina(codProd);
            listadoGeneral();
            JOptionPane.showMessageDialog(null, "Se elimino correctamente");
        }

    }

    void limpiaDatos() {
        txtCod.setText("");
        txtNom.setText("");
        txtVen.setText("");
        txtProv.setText("");
        txtSto.setText("");
        txtCom.setText("");
    }

    void habilitaDatos(boolean hab) {
        txtCod.setEnabled(hab);
        txtProv.setEnabled(hab);
        txtNom.setEnabled(hab);
        txtCom.setEnabled(hab);
        txtVen.setEnabled(hab);
        txtVen.setEnabled(hab);

    }

    void listado() {

        
        try {
            desc = JOptionPane.showInputDialog("codigo producto del cliente a buscar", "");
            if (desc.isEmpty()) {
                ArrayList<producto> lprod = new ArrayList();
                lprod = cprod.listaProv();

                mostrar(lprod);
            } else {
                ArrayList<producto> lprod = new ArrayList();
                lprod = cprod.listaProvNombre(desc);
                mostrar(lprod);

            }

        } catch (NullPointerException e) {
        }

    }

    void recuperaDatosTabla() {
        int fila = muestra.getSelectedRow();

        txtCod.setText(muestra.getValueAt(fila, 0).toString());
        txtProv.setText(muestra.getValueAt(fila, 1).toString());
        txtNom.setText(muestra.getValueAt(fila, 3).toString());
        txtCom.setText(muestra.getValueAt(fila, 4).toString());
        txtVen.setText(muestra.getValueAt(fila, 5).toString());
        txtSto.setText(muestra.getValueAt(fila, 6).toString());
    }

    public formProducto() {
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        listadoGeneral();
        habilitaDatos(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        muestra = new javax.swing.JTable();
        txtCod = new javax.swing.JTextField();
        txtProv = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtCom = new javax.swing.JTextField();
        btBus = new javax.swing.JButton();
        btAgre = new javax.swing.JButton();
        btEli = new javax.swing.JButton();
        btMod = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        txtSto = new javax.swing.JTextField();
        txtVen = new javax.swing.JTextField();
        btSal = new javax.swing.JButton();
        btNue = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        vp = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        muestra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo Producto", "Codigo  Proveedor", "Nombre Proveedor", "Nombre Producto", "Precio Compra", "Precio Venta", "Stock"
            }
        ));
        muestra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                muestraMouseClicked(evt);
            }
        });
        muestra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                muestraKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(muestra);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 381, 760, 100));
        getContentPane().add(txtCod, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 140, 280, -1));
        getContentPane().add(txtProv, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, 200, -1));

        txtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNomKeyTyped(evt);
            }
        });
        getContentPane().add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, 280, -1));

        txtCom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtComKeyTyped(evt);
            }
        });
        getContentPane().add(txtCom, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 280, -1));

        btBus.setText("Buscar");
        btBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBusActionPerformed(evt);
            }
        });
        getContentPane().add(btBus, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 190, 90, -1));

        btAgre.setText("Agregar");
        btAgre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgreActionPerformed(evt);
            }
        });
        getContentPane().add(btAgre, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 150, -1, -1));

        btEli.setText("Eliminar");
        btEli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEliActionPerformed(evt);
            }
        });
        getContentPane().add(btEli, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 190, -1, -1));

        btMod.setText("Modificar");
        btMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btModActionPerformed(evt);
            }
        });
        getContentPane().add(btMod, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 230, 90, -1));

        jButton4.setText("Imprimir");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 270, 90, -1));

        jButton1.setText("Prov");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 180, 40, -1));

        txtSto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtStoKeyTyped(evt);
            }
        });
        getContentPane().add(txtSto, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, 280, -1));

        txtVen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtVenKeyTyped(evt);
            }
        });
        getContentPane().add(txtVen, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 300, 280, -1));

        btSal.setText("Salir");
        btSal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalActionPerformed(evt);
            }
        });
        getContentPane().add(btSal, new org.netbeans.lib.awtextra.AbsoluteConstraints(676, 230, 80, -1));

        btNue.setText("Nuevo");
        btNue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNueActionPerformed(evt);
            }
        });
        getContentPane().add(btNue, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 150, 90, -1));

        jButton2.setText("Venta");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 270, 80, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/formProducto.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        vp.setText("0");
        vp.setEnabled(false);
        getContentPane().add(vp, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 100, -1, -1));

        jMenu1.setText("Menu");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBusActionPerformed
        listado();
    }//GEN-LAST:event_btBusActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setVisible(false);
        formMenu a = new formMenu();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

  
        formProveedor a = new formProveedor();
        a.setVisible(true);
 formProveedor.v.setText("1");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btAgreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgreActionPerformed
        if (validaDatos() == true) {
            recuperaDatos();
            producto pro = new producto(codProd, codProv, nomProd, preCom, preVen, stock);
            if (op == 0) {
                cprod.adiciona(pro);
                JOptionPane.showMessageDialog(null, "Datos Grabados");
            } else {
                cprod.modifica(pro);
                JOptionPane.showMessageDialog(null, "Datos Modificados");
            }
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        }
    }//GEN-LAST:event_btAgreActionPerformed

    private void btModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btModActionPerformed
        op = 1;
        habilitaDatos(true);
        botones(true, true, true, true);
    }//GEN-LAST:event_btModActionPerformed

    private void btEliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEliActionPerformed
        elimina();
    }//GEN-LAST:event_btEliActionPerformed

    private void btNueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNueActionPerformed
      
        habilitaDatos(true);
        botones(false, true, false, true);
        btSal.setText("Cancelar");
        txtCod.requestFocus();
    }//GEN-LAST:event_btNueActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      
         if ((vp.getText()).equals("0")){
       formVenta a = new formVenta();
        a.setVisible(true);
       
 }else{ 
 }
        String n = txtCod.getText();
        String m = txtVen.getText();
        formVenta.txtCop.setText(n);
        formVenta.txtprecio.setText(m);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void muestraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_muestraMouseClicked
     recuperaDatosTabla();
    }//GEN-LAST:event_muestraMouseClicked

    private void muestraKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_muestraKeyPressed
     recuperaDatosTabla();
    }//GEN-LAST:event_muestraKeyPressed

    private void btSalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalActionPerformed
        if (btSal.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        } else {
            dispose();
        }
    }//GEN-LAST:event_btSalActionPerformed

    private void txtNomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNomKeyTyped
      char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtNomKeyTyped

    private void txtComKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtComKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car)) || (car == '.')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtComKeyTyped

    private void txtVenKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtVenKeyTyped
          char car = evt.getKeyChar();
        if ((Character.isDigit(car)) || (car == '.')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtVenKeyTyped

    private void txtStoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtStoKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car)) ) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtStoKeyTyped

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       try {
            ConexionBD cone=new ConexionBD();
            Connection con =null;
            con=cone.conecta();
            String archivo="C:/Users/USUARIO/Documents/ProgramacionAvnazada/farmaciasEsperanza/src/reportes/rProducto.jasper";
            JasperReport reporte=null;
            reporte=(JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
               Map parametro =new HashMap();
            desc=desc+"%";
            parametro.put("desc",desc);
            jp=JasperFillManager.fillReport(reporte,parametro,con);
            JasperViewer jv= new JasperViewer(jp,false);
            jv.setTitle("REPORTE CLIENTES");
            jv.setVisible(true);
        } catch (JRException ex) {
           
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAgre;
    private javax.swing.JButton btBus;
    private javax.swing.JButton btEli;
    private javax.swing.JButton btMod;
    private javax.swing.JButton btNue;
    private javax.swing.JButton btSal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable muestra;
    private javax.swing.JTextField txtCod;
    private javax.swing.JTextField txtCom;
    private javax.swing.JTextField txtNom;
    public static javax.swing.JTextField txtProv;
    private javax.swing.JTextField txtSto;
    private javax.swing.JTextField txtVen;
    public static javax.swing.JTextField vp;
    // End of variables declaration//GEN-END:variables

}
