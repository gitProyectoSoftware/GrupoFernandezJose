package modelo;
public class proveedor {
    
    public String codProv,nomProv,dirProv;
    public int telProv;

    public proveedor() {
    }

    public proveedor(String codProv, String nomProv, String dirProv, int telProv) {
        this.codProv = codProv;
        this.nomProv = nomProv;
        this.dirProv = dirProv;
        this.telProv = telProv;
    }

    public String getCodProv() {
        return codProv;
    }

    public void setCodProv(String codProv) {
        this.codProv = codProv;
    }

    public String getNomProv() {
        return nomProv;
    }

    public void setNomProv(String nomProv) {
        this.nomProv = nomProv;
    }

    public String getDirProv() {
        return dirProv;
    }

    public void setDirProv(String dirProv) {
        this.dirProv = dirProv;
    }

    public int getTelProv() {
        return telProv;
    }

    public void setTelProv(int telProv) {
        this.telProv = telProv;
    }
 
   
}
