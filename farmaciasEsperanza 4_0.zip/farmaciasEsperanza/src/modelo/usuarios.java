package modelo;
public class usuarios {
    public int id;
    public String user,clave,nom,nivel;

    public usuarios() {
    }

    public usuarios(int id, String user, String clave, String nom, String nivel) {
        this.id = id;
        this.user = user;
        this.clave = clave;
        this.nom = nom;
        this.nivel = nivel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
    
    
}
