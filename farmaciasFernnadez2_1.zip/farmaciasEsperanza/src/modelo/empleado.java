package modelo;
public class empleado {
 
    public String ciEmp,nomEmp,apeEmp,proEmp,dirEmp;
    public int telEmp;

    public empleado() {
    }

    public empleado(String ciEmp, String nomEmp, String apeEmp, String proEmp, String dirEmp, int telEmp) {
        this.ciEmp = ciEmp;
        this.nomEmp = nomEmp;
        this.apeEmp = apeEmp;
        this.proEmp = proEmp;
        this.dirEmp = dirEmp;
        this.telEmp = telEmp;
    }

    public String getCiEmp() {
        return ciEmp;
    }

    public void setCiEmp(String ciEmp) {
        this.ciEmp = ciEmp;
    }

    public String getNomEmp() {
        return nomEmp;
    }

    public void setNomEmp(String nomEmp) {
        this.nomEmp = nomEmp;
    }

    public String getApeEmp() {
        return apeEmp;
    }

    public void setApeEmp(String apeEmp) {
        this.apeEmp = apeEmp;
    }

    public String getProEmp() {
        return proEmp;
    }

    public void setProEmp(String proEmp) {
        this.proEmp = proEmp;
    }

    public String getDirEmp() {
        return dirEmp;
    }

    public void setDirEmp(String dirEmp) {
        this.dirEmp = dirEmp;
    }

    public int getTelEmp() {
        return telEmp;
    }

    public void setTelEmp(int telEmp) {
        this.telEmp = telEmp;
    }

  
}
