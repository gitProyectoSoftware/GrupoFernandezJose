package farmaciasesperanza;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import modelo.empleado;
public class cEmpleado {
     ConexionBD cone= new ConexionBD();  
            public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <empleado> lemp = new ArrayList();
        try {
            
           while(rs.next()){
                empleado emp =new empleado();
               emp.setCiEmp(rs.getString("ci_emp"));
                emp.setNomEmp(rs.getString("nombre_emp"));
                 emp.setApeEmp(rs.getString("apellido_emp"));
                  emp.setProEmp(rs.getString("profesion_emp"));
                  emp.setDirEmp(rs.getString("direccion_emp"));
                  emp.setTelEmp(rs.getInt("telefono_emp"));
                  lemp.add(emp);  
            } 
        } catch (SQLException e) {
        }
        return lemp;
         
    }
    public ArrayList listaEmp(){
        ArrayList <empleado> lemp = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_empleado";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lemp=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lemp;
    }
     public ArrayList listaEmpNombre(String nom){
        ArrayList <empleado> lemp = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_empleado where nombre_emp like '"+nom+"%'";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lemp=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lemp;
    }   
        public void adiciona(empleado emp){
        try {
            Connection con;
            con=cone.conecta();
        String sql="INSERT INTO t_empleado(ci_emp,nombre_emp,apellido_emp,profesion_emp,direccion_emp,telefono_emp) VALUES ('"+emp.getCiEmp()+"','"+emp.getNomEmp()+"','"+emp.getApeEmp()+"','"+emp.getProEmp()+"','"+emp.getDirEmp()+"',"+emp.getTelEmp()+")";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
              public void modifica(empleado emp){
        try {
            Connection con;
            con=cone.conecta();
            String sql="UPDATE t_empleado SET ci_emp='"+emp.getCiEmp()+"',nombre_emp='"+emp.getNomEmp()+"',apellido_emp='"+emp.getApeEmp()+"',profesion_emp='"+emp.getProEmp()+"',direccion_emp='"+emp.getDirEmp()+"',telefono_emp="+emp.getTelEmp()+" WHERE ci_emp='"+emp.getCiEmp()+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
                 public void elimina(String ci){
        try {
            Connection con;
            con=cone.conecta();
            String sql="DELETE FROM t_empleado WHERE ci_emp='"+ci+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
