package modelo;
public class cliente {
   public String ci, nomCli, apeCli;
    public int telCli;
    public cliente() {
    }
    public cliente(String ci, String nomCli, String apeCli, int telCli) {
        this.ci = ci;
        this.nomCli = nomCli;
        this.apeCli = apeCli;
        this.telCli = telCli;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getNomCli() {
        return nomCli;
    }

    public void setNomCli(String nomCli) {
        this.nomCli = nomCli;
    }

    public String getApeCli() {
        return apeCli;
    }

    public void setApeCli(String apeCli) {
        this.apeCli = apeCli;
    }

    public int getTelCli() {
        return telCli;
    }

    public void setTelCli(int telCli) {
        this.telCli = telCli;
    }

}
