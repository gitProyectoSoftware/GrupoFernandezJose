package form;

import farmaciasesperanza.ConexionBD;
import farmaciasesperanza.cCliente;
import java.sql.Connection;
import modelo.cliente;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class formCliente extends javax.swing.JFrame {
public String desc="";
    public String ci, nomCli, apeCli;
    public int telCli;
    public int op = 0;
    cCliente ccli = new cCliente();

    boolean validaDatos() {
        boolean sw = true;
        if (txtCi.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(null, "Debe ingresar el Ci del Cliente");
            txtCi.requestFocus();
        } else {
            if (txtNom.getText().trim().length() == 0) {
                sw = false;
                JOptionPane.showMessageDialog(null, "Debe ingresar el Nombre del cliente");
                txtNom.requestFocus();
            } else {
                if (txtApe.getText().trim().length() == 0) {
                    sw = false;
                    JOptionPane.showMessageDialog(null, "Debe ingresar el Apellido del cliente");
                    txtApe.requestFocus();
                } else {
                    if (txtTel.getText().trim().length() == 0) {
                        sw = false;
                        JOptionPane.showMessageDialog(null, "Debe ingresar el Telefono del cliente");
                        txtTel.requestFocus();
                    }
                }
            }
        }
        return sw;
    }
void elimina(){
    int resp;
    int  fila=pa.getSelectedRow();
    ci=pa.getValueAt(fila,0).toString();
    resp=JOptionPane.showConfirmDialog(null,"Desea Eliminar ","Eliminar",JOptionPane.YES_NO_OPTION);
    if(resp==0){
         ccli.elimina(ci);
    listadoGeneral();
    JOptionPane.showMessageDialog(null,"Se elimino correctamente");
    }
    
   
}
    void limpiaDatos() {
        txtCi.setText("");
        txtNom.setText("");
        txtApe.setText("");
        txtTel.setText("");
    }

    void botones(boolean nue, boolean agre, boolean bus, boolean sal) {
        btNue.setEnabled(nue);
        btAgre.setEnabled(agre);
        btBus.setEnabled(bus);
        btSal.setEnabled(sal);
    }

    void habilitaDatos(boolean hab) {
        txtCi.setEnabled(hab);
        txtNom.setEnabled(hab);
        txtApe.setEnabled(hab);
        txtTel.setEnabled(hab);

    }

    void mostrar(ArrayList<cliente> lcli) {
        String mat[][] = new String[lcli.size()][4];
        int i;
        for (i = 0; i < lcli.size(); i++) {
            mat[i][0] = lcli.get(i).getCi() + "";
            mat[i][1] = lcli.get(i).getNomCli();
            mat[i][2] = lcli.get(i).getApeCli();
            mat[i][3] = lcli.get(i).getTelCli() + "";
        }
        pa.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Ci", "Nombre", "Apellido", "Telefono"
                }
        ));
    }

    void listado() {
 
        try {
            desc = JOptionPane.showInputDialog("Nombre del cliente a buscar", "");
            if (desc.isEmpty()) {
                ArrayList<cliente> lcli = new ArrayList();
                lcli = ccli.listaCli();
                mostrar(lcli);
            } else {
                ArrayList<cliente> lcli = new ArrayList();
                lcli = ccli.listaCliNombre(desc);
                mostrar(lcli);
            }
        } catch (NullPointerException e) {
        }

    }

    void listadoGeneral() {
        ArrayList<cliente> lcli = new ArrayList();
        lcli = ccli.listaCli();
        mostrar(lcli);
        if (pa.getRowCount() > 0) {
            botones(true, false, true, true);
        } else {
            botones(true, false, true, true);
        }
    }

    void recuperaDatos() {
        ci = txtCi.getText();
        nomCli = txtNom.getText();
        apeCli = txtApe.getText();
        telCli = Integer.parseInt(txtTel.getText());
    }

    void recuperaDatosTabla() {
        int fila = pa.getSelectedRow();
        txtCi.setText(pa.getValueAt(fila, 0).toString());
        txtNom.setText(pa.getValueAt(fila, 1).toString());
        txtApe.setText(pa.getValueAt(fila, 2).toString());
        txtTel.setText(pa.getValueAt(fila, 3).toString());
    }

    public formCliente() {

        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        habilitaDatos(false);
        listadoGeneral();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        txtCi = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtApe = new javax.swing.JTextField();
        txtTel = new javax.swing.JTextField();
        btBus = new javax.swing.JButton();
        btNue = new javax.swing.JButton();
        btSal = new javax.swing.JButton();
        btAgre = new javax.swing.JButton();
        jTable1 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        pa = new javax.swing.JTable();
        btImp = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        jMenuItem1.setText("Eliminar");
        jMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem1MouseClicked(evt);
            }
        });
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("Modificar");
        jMenuItem2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem2MouseClicked(evt);
            }
        });
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCiKeyTyped(evt);
            }
        });
        getContentPane().add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 280, -1));

        txtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNomKeyTyped(evt);
            }
        });
        getContentPane().add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 280, -1));

        txtApe.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApeKeyTyped(evt);
            }
        });
        getContentPane().add(txtApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 280, -1));

        txtTel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelKeyTyped(evt);
            }
        });
        getContentPane().add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 280, -1));

        btBus.setText("Buscar");
        btBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBusActionPerformed(evt);
            }
        });
        getContentPane().add(btBus, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, 80, -1));

        btNue.setText("Nuevo");
        btNue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNueActionPerformed(evt);
            }
        });
        getContentPane().add(btNue, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 130, 80, -1));

        btSal.setText("Salir");
        btSal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalActionPerformed(evt);
            }
        });
        getContentPane().add(btSal, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 210, 80, -1));

        btAgre.setText("Agregar");
        btAgre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAgreActionPerformed(evt);
            }
        });
        getContentPane().add(btAgre, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 130, 80, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre", "Direccion", "Telefono"
            }
        ));
        getContentPane().add(jTable1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jButton3.setText("Modificar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 170, -1, -1));

        jButton1.setText("Eliminar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 210, 80, -1));

        pa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Ci", "Nombre", "Apellido", "Telefono"
            }
        ));
        pa.setComponentPopupMenu(jPopupMenu1);
        pa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paMouseClicked(evt);
            }
        });
        pa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                paKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(pa);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, 690, 160));

        btImp.setText("Imprimir");
        btImp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btImpActionPerformed(evt);
            }
        });
        getContentPane().add(btImp, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 250, -1, -1));

        jButton2.setText("Venta");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 250, 80, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/formcliente.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jMenu1.setText("Menu");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBusActionPerformed
        listado();
    }//GEN-LAST:event_btBusActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setVisible(false);
        formMenu a = new formMenu();
        a.setVisible(true);
    }//GEN-LAST:event_jMenu1MouseClicked

    private void txtTelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtTelKeyTyped

    private void txtCiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCiKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtCiKeyTyped

    private void txtNomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNomKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtNomKeyTyped

    private void txtApeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApeKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {

        } else {
            evt.consume();
        }
    }//GEN-LAST:event_txtApeKeyTyped

    private void btAgreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAgreActionPerformed
        if (validaDatos() == true) {
            recuperaDatos();
            cliente cli = new cliente(ci, nomCli, apeCli, telCli);
            if (op == 0) {
                ccli.adiciona(cli);
                JOptionPane.showMessageDialog(null, "Datos Grabados");
            } else {
                ccli.modifica(cli);
                JOptionPane.showMessageDialog(null, "Datos Modificados");
            }
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        }
    }//GEN-LAST:event_btAgreActionPerformed

    private void btNueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNueActionPerformed
        limpiaDatos();
        habilitaDatos(true);
        botones(false, true, false, true);
        btSal.setText("Cancelar");
        txtCi.requestFocus();

    }//GEN-LAST:event_btNueActionPerformed

    private void btSalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalActionPerformed
        if (btSal.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btSal.setText("Salir");
        } else {
            dispose();
        }
    }//GEN-LAST:event_btSalActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        op = 1;
        habilitaDatos(true);
        botones(true, true, true, true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void paMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paMouseClicked
        recuperaDatosTabla();
    }//GEN-LAST:event_paMouseClicked

    private void paKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paKeyReleased
        recuperaDatosTabla();
    }//GEN-LAST:event_paKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
elimina();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem1MouseClicked

    }//GEN-LAST:event_jMenuItem1MouseClicked

    private void jMenuItem2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem2MouseClicked
 
    }//GEN-LAST:event_jMenuItem2MouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
           elimina();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
    op = 1;
        habilitaDatos(true);
        botones(true, true, true, true);    
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void btImpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btImpActionPerformed
         try {
            ConexionBD cone=new ConexionBD();
            Connection con =null;
            con=cone.conecta();
            String archivo="C:/Users/USUARIO/Documents/ProgramacionAvnazada/farmaciasEsperanza/src/reportes/rClientes.jasper";
            JasperReport reporte=null;
            reporte=(JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
            Map parametro =new HashMap();
            desc=desc+"%";
            parametro.put("desc",desc);
            jp=JasperFillManager.fillReport(reporte,parametro,con);
            JasperViewer jv= new JasperViewer(jp,false);
            jv.setTitle("REPORTE CLIENTES");
            jv.setVisible(true);
        } catch (JRException ex) {
           
        }
    }//GEN-LAST:event_btImpActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         String n=txtCi.getText();
       formVenta.txtCi.setText(n);
this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAgre;
    private javax.swing.JButton btBus;
    private javax.swing.JButton btImp;
    private javax.swing.JButton btNue;
    private javax.swing.JButton btSal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable pa;
    private javax.swing.JTextField txtApe;
    private javax.swing.JTextField txtCi;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtTel;
    // End of variables declaration//GEN-END:variables
}
