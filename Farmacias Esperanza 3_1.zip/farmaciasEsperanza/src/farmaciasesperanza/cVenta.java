package farmaciasesperanza;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import modelo.registroVenta;

public class cVenta {
      ConexionBD cone= new ConexionBD();
       public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <registroVenta> lven = new ArrayList();
        try {
            
           while(rs.next()){
                registroVenta ven =new registroVenta();
               ven.setCodVen(rs.getString("V.codigo_vent"));
                 ven.setCodProd(rs.getString("codigo_prod"));
                   ven.setNomProd(rs.getString("P.nombre_prod"));
                    ven.setCiCli(rs.getString("V.ci"));
                 ven.setCiEmp(rs.getString("V.ci_emp"));
                   ven.setCant(rs.getInt("V.cantidad")); 
                       ven.setPre(rs.getDouble("V.precio"));
                           ven.setFecha(rs.getString("V.fecha"));
                            lven.add(ven);  
            } 
        } catch (SQLException e) {
        }
        return lven;
         
    }
    public ArrayList listaProv(){
        ArrayList <registroVenta> lven = new ArrayList();
Connection con;
con=cone.conecta();
String    sql = "select V.codigo_vent,V.codigo_prod,P.nombre_prod,V.ci,V.ci_emp,V.cantidad,V.precio,V.fecha from t_ventas AS V INNER JOIN t_producto AS P ON V.codigo_prod=P.codigo_prod";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lven=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lven;
    }
     public ArrayList listaProvNombre(String nom){
        ArrayList <registroVenta> lven = new ArrayList();
Connection con;
con=cone.conecta();
String    sql = "select V.codigo_vent,V.codigo_prod,P.nombre_prod,V.ci_emp,V.ci,V.cantidad,V.precio,V.fecha from t_ventas AS V INNER JOIN t_producto AS P ON V.codigo_prod=P.codigo_prod where ci like '"+nom+"%'";



        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lven=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lven;
    }
      public void adiciona(registroVenta ven){
        try {
            Connection con;
            con=cone.conecta();
    
            String sql="INSERT INTO t_ventas(codigo_vent,codigo_prod,ci,ci_emp,cantidad,precio,fecha) VALUES ('"+ven.getCodVen()+"','"+ven.getCodProd()+"','"+ven.getCiCli()+"','"+ven.getCiEmp()+"',"+ven.getCant()+",'"+ven.getPre()+"','"+ven.getFecha()+"')";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
         public void modifica(registroVenta ven){
        try {
            Connection con;
            con=cone.conecta();
            String sql="UPDATE t_ventas SET codigo_prod='"+ven.getCodProd()+"',ci_emp='"+ven.getCiEmp()+"',cantidad="+ven.getCant()+",precio='"+ven.getPre()+"',fecha='"+ven.getFecha()+"' WHERE codigo_vent='"+ven.getCodVen()+"' AND ci='"+ven.getCiCli()+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
                public void elimina(String ci,String codProd,int cant,String Fech){
        try {
            Connection con;
            con=cone.conecta();
            String sql="DELETE FROM t_ventas WHERE codigo_vent='"+ci+"' AND codigo_prod='"+codProd+"' AND cantidad="+cant+" AND fecha='"+Fech+"'";
            Statement smt =con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
