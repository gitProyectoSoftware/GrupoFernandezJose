package modelo;
public class producto {
  
    public String codProd,codProv,nomProv,nomProd;
    public double preCom,preVen;
    public int stock;

    public producto() {
    }

    public producto(String codProd, String codProv, String nomProv, String nomProd, double preCom, double preVen, int stock) {
        this.codProd = codProd;
        this.codProv = codProv;
        this.nomProv = nomProv;
        this.nomProd = nomProd;
        this.preCom = preCom;
        this.preVen = preVen;
        this.stock = stock;
    }

    public String getCodProd() {
        return codProd;
    }

    public void setCodProd(String codProd) {
        this.codProd = codProd;
    }

    public String getCodProv() {
        return codProv;
    }

    public void setCodProv(String codProv) {
        this.codProv = codProv;
    }

    public String getNomProv() {
        return nomProv;
    }

    public void setNomProv(String nomProv) {
        this.nomProv = nomProv;
    }

    public String getNomProd() {
        return nomProd;
    }

    public void setNomProd(String nomProd) {
        this.nomProd = nomProd;
    }

    public double getPreCom() {
        return preCom;
    }

    public void setPreCom(double preCom) {
        this.preCom = preCom;
    }

    public double getPreVen() {
        return preVen;
    }

    public void setPreVen(double preVen) {
        this.preVen = preVen;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

   
}
