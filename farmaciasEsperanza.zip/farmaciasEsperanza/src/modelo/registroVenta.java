package modelo;
public class registroVenta {

public String codVen,codProd,nomProd,ciEmp,ciCli;
public int cant;
public double pre;
public String fecha;

    public registroVenta() {
    }

    public registroVenta(String codVen, String codProd, String nomProd, String ciEmp, String ciCli, int cant, double pre, String fecha) {
        this.codVen = codVen;
        this.codProd = codProd;
        this.nomProd = nomProd;
        this.ciEmp = ciEmp;
        this.ciCli = ciCli;
        this.cant = cant;
        this.pre = pre;
        this.fecha = fecha;
    }

    public String getCodVen() {
        return codVen;
    }

    public void setCodVen(String codVen) {
        this.codVen = codVen;
    }

    public String getCodProd() {
        return codProd;
    }

    public void setCodProd(String codProd) {
        this.codProd = codProd;
    }

    public String getNomProd() {
        return nomProd;
    }

    public void setNomProd(String nomProd) {
        this.nomProd = nomProd;
    }

    public String getCiEmp() {
        return ciEmp;
    }

    public void setCiEmp(String ciEmp) {
        this.ciEmp = ciEmp;
    }

    public String getCiCli() {
        return ciCli;
    }

    public void setCiCli(String ciCli) {
        this.ciCli = ciCli;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public double getPre() {
        return pre;
    }

    public void setPre(double pre) {
        this.pre = pre;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    

}
