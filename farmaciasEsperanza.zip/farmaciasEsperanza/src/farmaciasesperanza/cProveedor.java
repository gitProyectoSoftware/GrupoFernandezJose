package farmaciasesperanza;
import java.sql.ResultSet;

import modelo.proveedor;
import java.util.ArrayList;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class cProveedor {
    ConexionBD cone= new ConexionBD();
    public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <proveedor> lprov = new ArrayList();
        try {
            
           while(rs.next()){
                proveedor prov =new proveedor();
               prov.setCodProv(rs.getString("codigo_prov"));
                prov.setNomProv(rs.getString("nombre_prov"));
                 prov.setDirProv(rs.getString("direccion_prov"));
                  prov.setTelProv(rs.getInt("telefono"));
                  lprov.add(prov);  
            } 
        } catch (SQLException e) {
        }
        return lprov;
         
    }
    public ArrayList listaProv(){
        ArrayList <proveedor> lprov = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_provedor";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lprov=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lprov;
    }
     public ArrayList listaProvNombre(String nom){
        ArrayList <proveedor> lprov = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_provedor where nombre_prov like '"+nom+"%'";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lprov=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lprov;
    }
}
