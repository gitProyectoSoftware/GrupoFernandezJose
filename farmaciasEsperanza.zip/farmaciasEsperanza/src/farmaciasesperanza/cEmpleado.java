package farmaciasesperanza;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import modelo.empleado;
public class cEmpleado {
     ConexionBD cone= new ConexionBD();  
            public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <empleado> lemp = new ArrayList();
        try {
            
           while(rs.next()){
                empleado emp =new empleado();
               emp.setCiEmp(rs.getString("ci_emp"));
                emp.setNomEmp(rs.getString("nombre_emp"));
                 emp.setApeEmp(rs.getString("apellido_emp"));
                  emp.setProEmp(rs.getString("profesion_emp"));
                  emp.setDirEmp(rs.getString("direccion_emp"));
                  emp.setTelEmp(rs.getInt("telefono_emp"));
                  lemp.add(emp);  
            } 
        } catch (SQLException e) {
        }
        return lemp;
         
    }
    public ArrayList listaEmp(){
        ArrayList <empleado> lemp = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_empleado";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lemp=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lemp;
    }
     public ArrayList listaEmpNombre(String nom){
        ArrayList <empleado> lemp = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_empleado where nombre_emp like '"+nom+"%'";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lemp=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lemp;
    }   
}
