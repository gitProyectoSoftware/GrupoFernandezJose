package farmaciasesperanza;

import modelo.cliente;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class cCliente {
   ConexionBD cone= new ConexionBD();  
       public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <cliente> lcli = new ArrayList();
        try {
            
           while(rs.next()){
                cliente cli =new cliente();
               cli.setCi(rs.getString("ci"));
                cli.setNomCli(rs.getString("nombre_cli"));
                 cli.setApeCli(rs.getString("apellido_cli"));
                  cli.setTelCli(rs.getInt("telefono_cli"));
                  lcli.add(cli);  
            } 
        } catch (SQLException e) {
        }
        return lcli;
         
    }
    public ArrayList listaCli(){
        ArrayList <cliente> lcli = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_cliente";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lcli=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lcli;
    }
     public ArrayList listaCliNombre(String nom){
        ArrayList <cliente> lcli = new ArrayList();
Connection con;
con=cone.conecta();
String sql="select * from t_cliente where nombre_cli like '"+nom+"%'";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lcli=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lcli;
    }
}
