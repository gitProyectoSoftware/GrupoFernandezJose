package farmaciasesperanza;
import java.sql.*;

public class ConexionBD {
    Connection con=null;
    public Connection conecta() 
    {
        String dbURL="jdbc:mysql://localhost:3306/farmaciabasee";
        String user="root";
        String clave="";
        try {
            Class.forName("com.mysql.jdbc.Driver");
             con=DriverManager.getConnection(dbURL,user,clave);
        } catch (ClassNotFoundException |SQLException  ex) {
           System.out.println("Error en la conexion");
        }
  
        return con;
    }
}
