package farmaciasesperanza;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import modelo.registroVenta;

public class cVenta {
      ConexionBD cone= new ConexionBD();
       public ArrayList recuperaDatos(ResultSet rs){
        ArrayList <registroVenta> lven = new ArrayList();
        try {
            
           while(rs.next()){
                registroVenta ven =new registroVenta();
               ven.setCodVen(rs.getString("V.codigo_vent"));
                 ven.setCodProd(rs.getString("codigo_prod"));
                   ven.setNomProd(rs.getString("P.nombre_prod"));
                    ven.setCiCli(rs.getString("V.ci"));
                 ven.setCiEmp(rs.getString("V.ci_emp"));
                   ven.setCant(rs.getInt("V.cantidad")); 
                       ven.setPre(rs.getDouble("V.precio"));
                           ven.setFecha(rs.getString("V.fecha"));
                            lven.add(ven);  
            } 
        } catch (SQLException e) {
        }
        return lven;
         
    }
    public ArrayList listaProv(){
        ArrayList <registroVenta> lven = new ArrayList();
Connection con;
con=cone.conecta();
String    sql = "select V.codigo_vent,V.codigo_prod,P.nombre_prod,V.ci,V.ci_emp,V.cantidad,V.precio,V.fecha from t_ventas AS V INNER JOIN t_producto AS P ON V.codigo_prod=P.codigo_prod";

        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
            lven=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lven;
    }
     public ArrayList listaProvNombre(String nom){
        ArrayList <registroVenta> lven = new ArrayList();
Connection con;
con=cone.conecta();
String    sql = "select V.codigo_vent,V.codigo_prod,P.nombre_prod,V.ci_emp,V.ci,V.cantidad,V.precio,V.fecha from t_ventas AS V INNER JOIN t_producto AS P ON V.codigo_prod=P.codigo_prod where ci like '"+nom+"%'";



        try {
            Statement smt= con.createStatement();
            ResultSet rs =smt.executeQuery(sql);
             lven=recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
return lven;
    }
    
}
