package farmaciasesperanza;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.producto;

public class cProducto {

    ConexionBD cone = new ConexionBD();

    public ArrayList recuperaDatos(ResultSet rs) {
        ArrayList<producto> lprod = new ArrayList();
        try {

            while (rs.next()) {
                producto prod = new producto();
                prod.setCodProd(rs.getString("codigo_prod"));
                prod.setCodProv(rs.getString("codigo_prov"));
                prod.setNomProv(rs.getString("nombre_prov"));
                prod.setNomProd(rs.getString("nombre_prod"));
                prod.setPreCom(rs.getDouble("precio_compra"));
                prod.setPreVen(rs.getDouble("precio_venta"));
                prod.setStock(rs.getInt("stock"));
                lprod.add(prod);
            }
        } catch (SQLException e) {
        }
        return lprod;

    }

    public ArrayList listaProv() {
        ArrayList<producto> lprod = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select P.codigo_prod,P.codigo_prov,PR.nombre_prov,P.nombre_prod,P.precio_compra,P.precio_venta,P.stock from t_producto AS P INNER JOIN t_provedor AS PR ON P.codigo_prov=PR.codigo_prov";

        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lprod = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lprod;
    }

    public ArrayList listaProvNombre(String nom) {
        ArrayList<producto> lprod = new ArrayList();
        Connection con;
        con = cone.conecta();
          String sql = "select P.codigo_prod,P.codigo_prov,PR.nombre_prov,P.nombre_prod,P.precio_compra,P.precio_venta,P.stock from t_producto AS P INNER JOIN t_provedor AS PR ON P.codigo_prov=PR.codigo_prov where  P.codigo_prod like '" + nom + "%'";



        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lprod = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(cProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lprod;
    }

}
